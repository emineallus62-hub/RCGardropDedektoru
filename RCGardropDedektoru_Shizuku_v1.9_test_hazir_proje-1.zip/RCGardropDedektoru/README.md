# RC Gardırop Dedektörü v1.1

Romance Club yerel verilerini Shizuku üzerinden tarayan Android uygulaması.

## v1.1 değişiklikleri
- `account.json` içindeki `acomp` ve `apks` dizilerini aynı JSON nesnesi içinde ilişkilendirir.
- Bu ilişkiyi `ACCOUNT_PAIR_ITEM` olarak raporlar.
- `ACCOUNT_PAIRS` sayacını ekler.
- Eşleşmelerin tek başına sahiplik kanıtı olmadığı açıkça belirtilir.
- Tarama ve aday Master eşleştirme altyapısı korunur.

## Önemli
Uygulama, gerçek sahiplik kaynağı kesin doğrulanmadan "eksik kıyafet" sonucu üretmez. `story...` ID'sinin katalog sırasına göre eşleştirilmesi yalnızca aday eşleşmedir.

Build: JDK 17 + Gradle 8.7 + Android Gradle Plugin 8.5.2.


## v1.9 — ilk gerçek test için

Bu proje artık GitHub Actions üzerinden doğrudan debug APK üretecek şekilde hazırlanmıştır. Workflow, JDK 17 ve Gradle 8.7 kullanır; AGP 8.5.x için Gradle 8.7 ve JDK 17 Android'in uyumluluk belgeleriyle uyumludur.

Üretilen dosya: `app/build/outputs/apk/debug/app-debug.apk`

### En kısa test yolu
1. Projeyi bir GitHub repository'sine yükleyin.
2. **Actions → Build APK → Run workflow** seçin.
3. İşlem bitince **Artifacts → RC-Gardrop-Dedektoru-debug** içinden APK'yı alın.
4. Telefonda Shizuku açıkken APK'yı kurun.
5. Uygulamada **Shizuku izni ver → Romance Club'ı Tara**.

Not: Bu çalışma ortamında Android SDK/Gradle kurulu olmadığı için APK'yı burada fiziksel olarak derleyemiyorum; proje tarafında derleme hattı hazırdır.
