# Shizuku starts UserService by class name, so keep it and its AIDL binder.
-keep class com.beren.rcwardrobe.service.FileScanService { *; }
-keep interface com.beren.rcwardrobe.IFileScanService { *; }
