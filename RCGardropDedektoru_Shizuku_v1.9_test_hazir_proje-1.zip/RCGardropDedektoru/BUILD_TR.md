# Build / Kurulum Notu

Bu proje Android Studio veya GitHub Actions ile derlenebilir.

- JDK: 17
- Gradle: 8.7
- Android Gradle Plugin: 8.5.2
- compileSdk: 35

GitHub Actions workflow `:app:assembleDebug` çalıştırır ve debug APK'yı artifact olarak yükler.

Uygulama Romance Club paketini Shizuku ile doğrudan tarar; proje klasörü Android/data içine konmaz.
